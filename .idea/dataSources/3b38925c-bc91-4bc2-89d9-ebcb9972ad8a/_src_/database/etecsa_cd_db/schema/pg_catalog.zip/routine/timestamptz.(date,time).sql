create function pg_catalog.timestamptz(date, time without time zone) returns timestamp with time zone
LANGUAGE SQL
AS $$
select cast(($1 + $2) as timestamp with time zone)
$$;
